from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import random

class ScreenManagement(ScreenManager):
    def __init__(self, **kwargs):
        super(ScreenManagement, self).__init__(**kwargs)


class OutputWindow(Screen):
    def __init__(self, **kwargs):
        super(OutputWindow, self).__init__(**kwargs)
        words = open('words.txt', 'r')
        translations = open('translations.txt', 'r')
        all_words = words.read()
        all_translations = translations.read()
        words.close()
        translations.close()
        self.all_words = all_words.split(sep="\n")
        self.all_translations = all_translations.split(sep="\n")
        self.amount_words = len(self.all_words)
        self.dictionary1 = dict()
        for i in range(len(self.all_words)):
            self.dictionary1[self.all_words[i]] = self.all_translations[i]
            self.ActiveWord = "0"
        self.ActiveWord = self.generate_word(self)
        a = "123"
        bl = BoxLayout(orientation="vertical", padding=2, spacing=2)
        self.word_to_check = Label(text="Введите перевод слова: " + self.ActiveWord, font_size='30sp')
        self.word_entry = TextInput(multiline=False, font_size='40sp')
        self.check = Button(text="Проверить", on_press=self.submit, background_normal="", background_color=[0.5, 0.25, 0, 1], font_size='20sp')
        self.next_button = Button(text="Следующее слово", on_press=self.next_f, font_size='20sp')
        self.show_true = Button(text="Показать верное", on_press=self.show_true_f, font_size='30sp')
        self.quit_btn = Button(text="X", background_color = [1, 0, 0, 1], size_hint=(0.3, 1), on_press=self.exit_button, font_size='50sp')
        bl.add_widget(self.word_to_check)
        bl.add_widget(self.word_entry)
        bl.add_widget(self.check)
        bl.add_widget(self.show_true)
        b1 = BoxLayout()
        b1.add_widget(self.next_button)
        b1.add_widget(self.quit_btn)
        bl.add_widget(b1)
        self.add_widget(bl)

    def submit(self, aza):
        if self.word_entry.text == self.dictionary1[self.ActiveWord]:
            self.check.background_color = [0.31, 0.78, 0.28, 1]
        else:
            self.check.background_color = [0.76, 0.23, 0.22, 1]

    def generate_word(self, obj=0):
        a = str(self.all_words[random.randint(0, self.amount_words - 1)])
        return a

    def next_f(self, obj=0):
        self.ActiveWord = self.generate_word(self)
        self.word_to_check.text = self.ActiveWord
        self.word_entry.text = ""
        self.check.background_color = [0.5, 0.25, 0, 1]

    def show_true_f(self, obj=0):
        self.word_entry.text = self.dictionary1[self.ActiveWord]

    def exit_button(self, obj=0):
        self.manager.current = "menu"


class InputWindow(Screen):
    def __init__(self, **kwargs):
        super(InputWindow, self).__init__(**kwargs)
        words = open('words.txt', 'r')
        translations = open('translations.txt', 'r')
        all_words = words.read()
        all_translations = translations.read()
        words.close()
        translations.close()

        bl_all = BoxLayout(orientation="vertical")
        bl_labels = BoxLayout(orientation="horizontal", size_hint=(1, .5))
        bl_labels.add_widget(Button(text="Введите сюда слово"))
        bl_labels.add_widget(Button(text="Введите сюда перевод"))
        bl_textinput = BoxLayout(orientation="horizontal")
        self.word = TextInput(text=all_words)
        self.translation = TextInput(text=all_translations)
        bl_textinput.add_widget(self.word)
        bl_textinput.add_widget(self.translation)
        bl_all.add_widget(bl_labels)
        bl_all.add_widget(bl_textinput)
        submit_button = Button(on_press=self.submit, text="Подтвердить", size_hint=(1, 0.2), background_color = [0, 1, 0, 1])
        exit_button = Button(on_press=self.exit_app, text="Отмена", size_hint=(1, 0.2), background_color = [1, 0, 0, 1])
        bl_all.add_widget(exit_button)
        bl_all.add_widget(submit_button)
        self.add_widget(bl_all)

    def exit_app(self, obj):
        self.manager.current = "menu"


    def submit(self, obj):
        words = open('words.txt', 'w')
        translations = open('translations.txt', 'w')
        words.write(str(self.word.text))
        translations.write(str(self.translation.text))
        words.close()
        translations.close()
        self.manager.current = "menu"


class MenuWindow(Screen):
        def __init__(self, **kwargs):
            super(MenuWindow, self).__init__(**kwargs)
            bl_all = BoxLayout(orientation="horizontal")
            self.input_btn = Button(text='Вводить слова', on_press=self.screen_input)
            self.output_btn = Button(text="Проверить\nзнание слов", on_press=self.screen_output)
            bl_all.add_widget(self.input_btn)
            bl_all.add_widget(self.output_btn)
            self.add_widget(bl_all)

        def screen_input(self, *args):
            self.manager.current = 'input'

        def screen_output(self, obj):
            self.manager.current = 'output'


class Application(App):
    def build(self):
        sm = ScreenManagement(transition=FadeTransition())
        sm.add_widget(MenuWindow(name='menu'))
        sm.add_widget(OutputWindow(name='output'))
        sm.add_widget(InputWindow(name="input"))

        return sm


if __name__ == "__main__":
    Application().run()
